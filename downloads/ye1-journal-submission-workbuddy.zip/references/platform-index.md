# 可选平台备注

默认由 Agent 依据当前页面完成任务，无须先查系统名单或等待专用适配。
仅在遇到具体问题，或已有备注可减少明显误操作时，按需阅读对应文件。

- [SNAPP](platform-snapp.md)：现有经验，包括独立投稿信位置、主稿重传后的字段变化、声明和保存核对。
- [Editorial Manager](platform-editorial-manager.md)：官网说明中通讯作者变更、PDF 预览和最终提交动作的易错点。

其他投稿系统直接使用[通用执行指引](execution.md)。发现反复出现的特殊问题时，可按[简短结构](platform-template.md)
补充脱敏备注，无需预先为每个出版社编写完整流程。
